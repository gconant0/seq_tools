#!/usr/bin/perl

use strict 'vars';

my(@genelist, $infilename, $filename, @allseqs, @seq, $i, $len, $j, $len2, $cmdargs);

$cmdargs=@ARGV;
if ($cmdargs>0) {


    $infilename=$ARGV[0];
    $filename=$ARGV[1];
    open (READSEQS, "<" . $infilename) or die "Can't open input sequence file $infilename\n";
    open (WRITESEQS, ">" . $filename) or die "Can't open output sequence file $filename\n";
    
    @allseqs=<READSEQS>;
    
    close (READSEQS);
     
    if ($ARGV[2] =~ /-s/i) {
	$genelist[2] = $ARGV[3];
	for($i=4; $i<@ARGV; $i++) {
		$genelist[2] = $genelist[2] . " " . $ARGV[$i];
        }
	$len = 3;
    }
    else { 
    	@genelist=@ARGV;
    
  	  $len=@genelist;
    }
    for($i=2; $i<$len; $i++)
    {
	$genelist[$i] =~ s/\*/@/g;
	@seq=find_sequence($genelist[$i], @allseqs);
	print WRITESEQS ">@genelist[$i]\n";
	$len2=@seq;
	for($j=0; $j<$len2; $j++) {
	    print WRITESEQS "$seq[$j]\n";}
    }
}    
else {
    print "Usage: find_genes.pl <Sequence file> <Output file> Gene1 Gene2 ...\n";
}



    
close(WRITESEQS);

sub find_sequence {
#Finds the sequence for a gene in a FASTA file
    
    my($genename, @inputseqs) = @_;
    my(@pro_lines, @retseq, $i, $j, $len, $found, $temp);
    
    $found = 0;
    $len=@inputseqs;
    $i=0;
    
    
    while (($i<$len) && ($found == 0))
    { 
	while (($i<$len) && (!($inputseqs[$i] =~ />/))) {$i++;}
	
	if (($inputseqs[$i] =~ />/)) {
	    $inputseqs[$i]=clean_line($inputseqs[$i]);
	    
	    if ($inputseqs[$i] =~ /$genename($|\s|:|%|\||,)/) {
		$found=1;
		    
	    }
	    else {
		$found=0;
	    }
	    
	}
    }
    if ($found) {
	$i++;
	while (($i<$len) && !($inputseqs[$i] =~ />/))
	{
	    $inputseqs[$i] =~ s/\n//; 
	    $inputseqs[$i] =~ s/\n//;
	    $inputseqs[$i] =~ s/\*//;
	   
	    push(@retseq, $inputseqs[$i]);
	    $i++;
	}
    }
    else {
	$retseq[0]="NONE";
    }
  
    return(@retseq);
}


sub clean_line {
    my ($line) =@_;
    $line =~ s/>//;
    $line =~ s/\n//; 
    $line =~ s/\\//g;
    $line =~ s/\///g;
    $line =~ s/\(/%/g;
    $line =~ s/\)/%/g;
    $line =~ s/\[/%/g;
    $line =~ s/\]/%/g;
    $line =~ s/\*/@/g;
    return($line);
}
