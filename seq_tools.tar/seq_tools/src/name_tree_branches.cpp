#include <iostream>
#include <fstream>
#include <math.h>
#include <string>
#include "exchange.h"
#include "tree.h"
#include "read_tree.h"
#include "read_seq.h"
#include "gen_dna_funcs.h"
#include "write_tree.h"
#include "phylo_model_matrix.h"
#include <string.h>

using namespace::std;



int main(int argc, char *argv[])
{
    int i=0, j,k, new_branch_id, ntaxa, nchars, num_prune, id_offset, init_tips;
    double sum_len;
    string treefile, treeline, model_file;
    TREE_TYPE my_type;
    BOOL end=FALSE, found_trans=FALSE, is_dupl=FALSE;
    ifstream fin;
    std::size_t found;

  //Classes
    Exchange *current_exchange, *new_exchange;
    Tree *current_tree, *new_tree;
    Branch **lookup_table, *curr_brn;
    Sequence_dataset *dummy_seqs;
    Read_PAUP_Tree get_tree;
    Read_PAUP_Tree_Ex get_dupl_tree;
    Write_Tree *writeout_tree;
    Phylo_Matrix *curr_model_matrix;
  
    if (argc>1) {
        treefile=argv[1];
        if (argc>2) { is_dupl=TRUE; model_file=argv[2];}
        current_exchange=new Exchange();
        current_exchange->set_have_data(FALSE);
        current_exchange->set_treefile(treefile.c_str());

        fin.open(treefile.c_str());
        if (fin.fail()){
            cerr<<"ERROR: Cannot open tree file "<<current_exchange->get_treefile()<<endl;
            return(-1);

        }
        else {
           // cout<<"Reading from "<<treefile<<endl;
            while((! fin.eof()) && (found_trans==FALSE)) {
                getline(fin, treeline);
                //cout<<"REad "<<treeline<<endl;
                found=treeline.find("Translate");
                if (found != std::string::npos) found_trans=TRUE;
            }
            ntaxa=0;
            while((! fin.eof()) && (end ==FALSE)) {
                getline(fin, treeline);
                found=treeline.find(";");
                if (found != std::string::npos) end=TRUE;
                else ntaxa++;
            }
            
        }

        cout<<"Tree has "<<ntaxa<<endl;
        current_exchange->set_num_taxa(ntaxa);
        current_exchange->set_num_sites(1);
        dummy_seqs=new Sequence_dataset(ntaxa,1);
   
        curr_model_matrix=new Phylo_Matrix(current_exchange, model_file);
        
        lookup_table=new Branch*[current_exchange->get_num_branches()];
    
        //Gets the tree
        if (is_dupl == FALSE)
            current_tree=get_tree.create_tree_from_file(current_exchange, dummy_seqs);
        else
            current_tree=get_dupl_tree.create_tree_from_file(current_exchange, dummy_seqs, curr_model_matrix, TRUE);
        
        if (current_tree==0) {
            return(-1);
        }
   
        for(k=0; k<current_exchange->get_num_branches(); k++)
            (*current_tree)[k]->name_this_branch();
        for(k=0; k<current_exchange->get_num_branches(); k++) {
            sum_len=(*current_tree)[k]->expect_subs_site();
            curr_brn=(*current_tree)[k]->get_parent();
            
            while(curr_brn!=0) {
//cout<<"Adding "<<curr_brn->expect_subs_site()<<" from "<<curr_brn->get_name()<<" to "<<sum_len<<endl;
                
                sum_len+=curr_brn->expect_subs_site();
                curr_brn=curr_brn->get_parent();
            }
            
            cout<<(*current_tree)[k]->get_name()<<"\t"<<(*current_tree)[k]->get_brnlen()<<"\t"<<(*current_tree)[k]->expect_subs_site()<<"\t";
            if ((*current_tree)[k]->get_parent() !=0)
                cout<<(*current_tree)[k]->get_parent()->get_name()<<"\t"<<(*current_tree)[k]->get_sibling()->get_name()<<"\t"<<sum_len<<endl;
            else
                cout<<"NONE\tNONE\t"<<sum_len<<"\n";
            
        }
        
        
        
        delete current_tree;
        //delete new_tree;
        delete dummy_seqs;
        return(0);
  } 
  else
    {
      cerr<<"Usage: name_tree_branches <tree file>(Dupl Model)\n";
      return(-1);
    }
}  //End main




