#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include "gen_dna_funcs.h"
#include "read_seq.h"
#include "write_seq.h"
#include "libranlib.h"


using namespace::std;


void parse_args(int argc, char **argv, string &infile, string &outfile, double &coverage, int &read_len, double &insert, BOOL &circular);


int main (int argc, char **argv)
{
	int i, j, k, genome_size, num_reads, read_len, val, ntaxa, nchars, r_insert, r1_start, r1_end, r2_start, r2_end ,offset, pos;
	long seed, seed2;
	double param, coverage, insert_size;
    string genome_file, outfile, name;
    BOOL circular;
    ifstream seedin;
	ofstream seedout;
	DATATYPE cdata=NUCLEIC;
	Read_Sequence *read_seq;
	Write_Sequence *write_seq=0;
	Sequence_dataset *current_data, *dataset;
		
	if (argc<5) {
		cerr<<"Usage: sim_paired_reads <in genome> <out file> coverage read_len insert\n";
		return(-1);
	}
	else	{
		parse_args(argc, argv, genome_file, outfile,coverage, read_len, insert_size, circular);

        read_seq=new Read_FASTA;
        
        current_data=read_seq->get_dataset(ntaxa, nchars, genome_file.c_str(), FALSE);
        
        num_reads=(int)((coverage*(*current_data)[0].Sequence_size())/((double) 2.0*read_len));
        
        cout<<"Simulating "<<num_reads<<" paired reads\n";
        
        //Make and log random number generator
		seedin.open("./seed.txt");
		seedin>>seed>>seed2;
		seedin.close();
		setall(seed, seed2);
		
        dataset=new Sequence_dataset(2*num_reads, read_len, cdata);
		
		for(i=0; i<num_reads; i++) {
            r_insert=(int)gennor(insert_size, 1.0);
            
            name = "SimRead_Num";
            
            stringstream ss;
            ss << i;
            name = name + ss.str();
            
            name = name + "_R1";
            
            (*dataset)[2*i].Assign_name(name.c_str());
            
            name = "SimRead_Num";
            
            name = name + ss.str();
            
            name = name + "_R2";
            
            (*dataset)[2*i+1].Assign_name(name.c_str());
            
            if (circular == FALSE) {
                offset=(2*read_len)+r_insert+1;
            
                r1_start=ignuin(0,(*current_data)[0].Sequence_size()-offset);
                r2_start=r1_start+read_len+r_insert;
                
                
                for(j=0; j<read_len; j++) {
                    (*dataset)[2*i].Assign_site(j, (*current_data)[0][r1_start+j]);
                    (*dataset)[2*i+1].Assign_site(j, (*current_data)[0][r2_start+j]);
                }
                
            }
            else {
                r1_start=ignuin(0,(*current_data)[0].Sequence_size());
                r2_start =(r1_start+read_len+r_insert)/(*current_data)[0].Sequence_size();
                
                pos=r1_start;
                for(j=0; j<read_len; j++) {
                    if (pos == ((*current_data)[0].Sequence_size()-1)) pos =0;
                    
                    (*dataset)[2*i].Assign_site(j, (*current_data)[0][pos]);
                    pos++;
                }
                pos=r2_start;
                for(j=0; j<read_len; j++) {
                    if (pos == ((*current_data)[0].Sequence_size()-1)) pos =0;
                    
                    (*dataset)[2*i+1].Assign_site(j, (*current_data)[0][pos]);
                    pos++;
                }
                
            }
        }
        
        write_seq=new Write_FASTA(outfile.c_str(), cdata);
			
        write_seq->write_dataset(2*num_reads, read_len, dataset);
			
	
		//Output seed for next run
		seedout.open("./seed.txt");
		getsd(&seed, &seed2);
		seedout<<seed<<"\t"<<seed2<<endl;
		seedout.close();
		
		
		delete current_data;
        delete dataset;
        delete write_seq;
		return(0);
    }
}//end main





void parse_args(int argc, char **argv, string &infile, string &outfile, double &coverage, int &read_len, double &insert, BOOL &circular)
{
    circular=FALSE;

    infile=argv[1];
    outfile=argv[2];
    coverage=string_to_float(argv[3]);
    read_len=string_to_int(argv[4]);
    insert=string_to_float(argv[5]);

    if (argc > 6) {
        if ((argv[6][1] == 'c') || (argv[6][1] == 'C'))
            circular=TRUE;
            }
}




