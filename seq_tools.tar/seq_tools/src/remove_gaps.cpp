#include <iostream>
#include "string.h"
#include "gen_dna_funcs.h"
#include "read_seq.h"
#include "write_seq.h"

using namespace::std;

int main (int argc, char **argv)
{
  int i, j, k, nchars, new_nchars, ntaxa;
  char infile[100], outfile[100];
  BOOL pro_seq=FALSE;
  DATATYPE type=NUCLEIC;
  Sequence_dataset *current_data, *new_dataset;
  Read_Sequence *read_seqs;
  Write_Sequence *write_seqs;
  
 if (argc<4)
   cerr<<"Usage: remove_gaps <infile> <outfile> -d:(DNA/PROTEIN)\n";
 else
   {
     strcpy(infile, argv[1]);
     strcpy(outfile, argv[2]);
     
      if(argv[3][3]=='P' || argv[3][3]=='p')
       {
	 pro_seq=TRUE;
	 type=PROTEIN;
       }
    
     switch(guess_dataformat(infile, strlen(infile)))
       {
       case NEXUS:
	 read_seqs=new Read_Nexus;
	 break;
       case PIR:
	 read_seqs=new Read_PIR;
	 break;
       case PHYLIP:
	 read_seqs=new Read_Phylip_interleave;
	 break;
       case FASTA:
	 read_seqs=new Read_FASTA;
	 break;
       } 
    

     switch(guess_dataformat(outfile, strlen(outfile)))
       {
       case NEXUS:
	 write_seqs=new Write_Nexus(outfile, type);
	 break;
       case PIR:
	 write_seqs=new Write_PIR(outfile, type);
	 break;
       case PHYLIP:
	 write_seqs=new Write_Phylip_interleave(outfile, type);
	 break;
       case FASTA:
	 write_seqs=new Write_FASTA(outfile, type);
	 break;
       } 
    
  
     current_data=read_seqs->get_dataset(ntaxa, nchars, infile, pro_seq);

    
     new_dataset=remove_gaps(current_data, pro_seq);

     new_nchars=(*new_dataset)[0].Sequence_size();
     
     write_seqs->write_dataset(ntaxa, new_nchars, new_dataset);
     
     delete current_data;
     delete new_dataset;
     delete read_seqs;

   } //End else for ok arguments
     
}//end main




