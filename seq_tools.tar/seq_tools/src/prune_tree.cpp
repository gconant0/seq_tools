#include <iostream>
#include <fstream>
#include <math.h>
#include <string>
#include "exchange.h"
#include "tree.h"
#include "read_tree.h"
#include "read_seq.h"
#include "gen_dna_funcs.h"
#include "write_tree.h"
#include <string.h>

using namespace::std;

void parse_args(int argc, char **argv, Exchange *curr_exchange, string &outtree, int &num_prune, string *&prune_list, TREE_TYPE &my_type);
void rebuild_tree (Branch *curr_old, Branch **lookup_table, Tree *new_tree, int &tips_so_far);
BOOL tip_in_clade(string tip_name, Branch *start);


int main(int argc, char *argv[])
{
    int i=0, j,k, cnt_left=0, cnt_right=0, new_branch_id, ntaxa, nchars, num_prune, id_offset, init_tips;
    string outtree, *prune_list, prog_name, treeline, *left_tips, *right_tips;
    BOOL valid, found_trans=FALSE, end=FALSE, is_prune, all_side1, one_side2;
    TREE_TYPE my_type;
    ifstream fin;
    std::size_t found;

  //Classes
    Exchange *current_exchange, *new_exchange;
    Tree *current_tree, *new_tree;
    Branch **lookup_table, *re_root=0, *orig_left, *orig_right;
    Sequence_dataset *dummy_seqs;
    Read_PAUP_Tree get_tree;
    Write_Tree *writeout_tree;
  
    if (argc>3) {
    
        current_exchange=new Exchange();
        current_exchange->set_have_data(FALSE);
        parse_args(argc, argv, current_exchange, outtree, num_prune, prune_list, my_type);

        fin.open(current_exchange->get_treefile());
        if (fin.fail()){
            cerr<<"ERROR: Cannot open tree file "<<current_exchange->get_treefile()<<endl;
            return(-1);

        }
        else {

            while((! fin.eof()) && (found_trans==FALSE)) {
                getline(fin, treeline);
                found=treeline.find("Translate");
                if (found != std::string::npos) found_trans=TRUE;
            }
            ntaxa=0;
            while((! fin.eof()) && (end ==FALSE)) {
                getline(fin, treeline);
                found=treeline.find(";");
                if (found != std::string::npos) end=TRUE;
                else ntaxa++;
            }
            
        }

        cout<<"Tree has "<<ntaxa<<endl;
        left_tips=new string [ntaxa];
        right_tips=new string[ntaxa];
        
        
        current_exchange->set_num_taxa(ntaxa);
        current_exchange->set_num_sites(1);
        dummy_seqs=new Sequence_dataset(ntaxa,1);
   
        lookup_table=new Branch*[current_exchange->get_num_branches()];
    
        //Gets the tree
        current_tree=get_tree.create_tree_from_file(current_exchange, dummy_seqs);
    
        if (current_tree==0) {
            return(-1);
        }
        
         for(k=0; k<current_exchange->get_num_branches(); k++) {
             if ((*current_tree)[k]->is_tip() == TRUE) {
                 is_prune = FALSE;
                 for(j=0; j<num_prune; j++) {
                     if (strcmp(prune_list[j].c_str(),(*current_tree)[k]->get_name())==0) is_prune=TRUE;
                 }
                 if (is_prune == FALSE) {
                     if (tip_in_clade((*current_tree)[k]->get_name(), current_tree->find_root()->get_child(0))==TRUE) {
                         left_tips[cnt_left]=(*current_tree)[k]->get_name();
                         cnt_left++;
                     }
                     else {
                         right_tips[cnt_right]=(*current_tree)[k]->get_name();
                         cnt_right++;
                     }
                 }
             }
         }
        
   
        for(k=0; k<current_exchange->get_num_branches(); k++) {
            cout<<(*current_tree)[k]->get_name()<<": "<<(*current_tree)[k]->get_brnlen()<<": "<<(*current_tree)[k]->expect_subs_site()<<endl;
            (*current_tree)[k]->set_brnlen((*current_tree)[k]->expect_subs_site());
        }
        
        for(i=0; i<num_prune; i++) {
            j=0;
            new_exchange=new Exchange();
            new_exchange->set_num_taxa(current_exchange->get_num_taxa()-1);
            new_exchange->set_num_sites(current_exchange->get_num_sites());
            
            
            new_tree=new Tree(new_exchange, TRUE);
            cout<<"Pruning "<<prune_list[i]<<endl;
            
            while((j<current_exchange->get_num_taxa()) && (strcmp(prune_list[i].c_str(), (*current_tree)[j]->get_name()) !=0)) j++;
            
            if (j<current_exchange->get_num_branches()) {
                current_tree->prune_from_tree((*current_tree)[j]);
                
                cout<<"Creating lookup table\n";
                new_branch_id=0;
                for(k=0; k<current_exchange->get_num_branches(); k++) {
                    valid=TRUE;
                    if (((*current_tree)[k]->get_sibling()==0) && ((*current_tree)[k] != current_tree->find_root())) valid=FALSE;
                    if (((*current_tree)[k]->is_tip() == FALSE ) && (((*current_tree)[k]->get_child(1) ==0) || ((*current_tree)[k]->get_child(0) ==0))) valid=FALSE;
                    
                    if (valid==TRUE) {
                        cout<<"Assigning "<<(*current_tree)[k]->get_brn_num()<<" to new "<<new_branch_id<<endl;
                        lookup_table[(*current_tree)[k]->get_brn_num()] =(*new_tree)[new_branch_id];
                        new_branch_id++;
                    }
                }
                init_tips=0;
                
                rebuild_tree (current_tree->find_root(), lookup_table, new_tree, init_tips);
                new_tree->set_root((*new_tree)[0]);

                
                new_tree->diganose_tree(new_tree->find_root());
                
                for(k=0; k<new_exchange->get_num_branches(); k++) {
                    if (((*new_tree)[k] != new_tree->find_root()) && ((*new_tree)[k] != new_tree->find_null_branch_id())) {
                        if ((*new_tree)[k]->expect_subs_site() ==0) {
                            (*new_tree)[k]->set_expect_subs_site(0.1);
                        }
                    }
                    
                    cout<<"Branch "<<k<<" name: "<<(*new_tree)[k]->get_name()<<" P: "<<(*new_tree)[k]->get_parent()<<" C1: "<<(*new_tree)[k]->get_child(0)<<" C2: "<<(*new_tree)[k]->get_child(1);
                    if ((*new_tree)[k]->is_tip())
                        cout<<" Tip: "<<(*new_tree)[k]->get_taxa_id()<<endl;
                    else
                        cout<<" Internal\n";
                }
                
                delete current_exchange;
                delete current_tree;
                current_tree=new_tree;
                current_exchange=new_exchange;
            }
            else {
                cerr<<"ERROR: No branch with name "<<prune_list[i]<<" found\n";
            }
        }
        
        current_tree->name_branches();
        
        for(j=0; j<cnt_left; j++) cout<<"Left: "<<j<<": "<<left_tips[j]<<endl;
        for(j=0; j<cnt_right; j++) cout<<"Right: "<<j<<": "<<right_tips[j]<<endl;
        
        cout<<"Left and right root are "<<current_tree->find_root()->get_child(0)->get_name()<<" and "<<current_tree->find_root()->get_child(1)->get_name()<<endl;
        orig_left=current_tree->find_root()->get_child(0);
        orig_right=current_tree->find_root()->get_child(1);
        
        for(k=0; k<current_exchange->get_num_branches(); k++) {
            all_side1=TRUE;
            one_side2=FALSE;
            for(j=0; j<cnt_left; j++) {
                if (tip_in_clade(left_tips[j],(*current_tree)[k])==FALSE)
                    all_side1=FALSE;
            }
            for(j=0; j<cnt_right; j++) {
                if (tip_in_clade(right_tips[j],(*current_tree)[k])==TRUE)
                    one_side2=TRUE;
            }
            
            if ((all_side1==TRUE) && (one_side2==FALSE)) {
                cout<<"Re-rooting at LEFT "<<(*current_tree)[k]->get_name()<<endl;
                if (((*current_tree)[k] != orig_left) &&((*current_tree)[k] != orig_right))
                    current_tree->re_root_tree((*current_tree)[k]);
            }
            else {
                all_side1=TRUE;
                one_side2=FALSE;
                for(j=0; j<cnt_right; j++) {
                    if (tip_in_clade(right_tips[j], (*current_tree)[k])==FALSE)
                        all_side1=FALSE;
                }
                for(j=0; j<cnt_left; j++) {
                    if (tip_in_clade(left_tips[j],(*current_tree)[k])==TRUE)
                        one_side2=TRUE;
                }
                
                if ((all_side1==TRUE) && (one_side2==FALSE)) {
                    cout<<"Re-rooting at RIGHT "<<(*current_tree)[k]->get_name()<<endl;
                    if (((*current_tree)[k] != orig_left) &&((*current_tree)[k] != orig_right))
                        current_tree->re_root_tree((*current_tree)[k]);
                }
            }
            
            
        }
        

        prog_name="Tree from prune_tree";
   
        if (my_type == NEXUS_TREE)
            writeout_tree=new Write_Nexus_Tree();
        else
            writeout_tree=new Write_Phylip_Tree();
        
        writeout_tree->write_tree(outtree, prog_name, current_tree, current_exchange);

    
        
        delete current_tree;
        //delete new_tree;
        delete dummy_seqs;
        return(0);
  } 
  else
    {
      cerr<<"Usage: prune_tree  <tree file> <output tree> -p:<Taxaname> -p<Taxaname> -t:NEXUS/PHYLIP.....\n";
      return(-1);
    }
}  //End main




void parse_args(int argc, char **argv, Exchange *curr_exchange, string &outtree, int &num_prune, string *&prune_list, TREE_TYPE &my_type)
{
    int i, j;
    string treefile;

    treefile=argv[1];
    outtree=argv[2];
    num_prune=0;
    my_type=NEXUS_TREE;

    curr_exchange->set_treefile(treefile.c_str());
    for(i=3; i<argc; i++) { if ((argv[i][1] =='p') || (argv[i][1] == 'P')) num_prune++;}
    
    prune_list=new string [num_prune];
    
    j=0;
    for(i=3; i<argc; i++) {
        switch(argv[i][1])
        {
            case 'p':
            case 'P':
                prune_list[j]=argv[i];
                prune_list[j]=prune_list[j].substr(3, prune_list[j].length()-3);
                j++;
                break;
            case 't':
            case 'T':
                if ((argv[i][3] == 'p') || (argv[i][3] == 'P')) my_type=PHYLIP_TREE;
            break;
    
        }
  }
  
}


void rebuild_tree (Branch *curr_old, Branch **lookup_table, Tree *new_tree, int &tips_so_far)
{
    Branch *new_me, *new_child1, *new_child2, *old_child1, *old_child2;
    if (curr_old->is_tip() ==FALSE) {
        old_child1=curr_old->get_child(0);
        old_child2=curr_old->get_child(1);
        new_me=lookup_table[curr_old->get_brn_num()];
        new_child1=lookup_table[old_child1->get_brn_num()];
        new_child2=lookup_table[old_child2->get_brn_num()];
        cout<<"Old brnaches"<<curr_old->get_name()<<" C1: "<<old_child1->get_name()<<" C2: "<<old_child2->get_name()<<endl;
        cout<<"New branch ids "<<new_me->get_brn_num()<<" C1 "<<new_child1->get_brn_num()<<" C2: "<<new_child2->get_brn_num()<<endl;
        
       
        
        new_tree->set_as_parent_child(new_me, new_child1, 0);
        new_tree->set_as_parent_child(new_me, new_child2, 1);
        new_tree->set_as_siblings(new_child1, new_child2);
        
        new_me->set_expect_subs_site(curr_old->get_brnlen());
        new_me->set_name(curr_old->get_name());
        new_me->set_tip(FALSE);
        
        if (curr_old->get_parent() ==0)
            new_me->set_parent(0);
            
        
        new_child1->set_expect_subs_site(old_child1->get_brnlen());
        new_child1->set_name(old_child1->get_name());
        new_child1->set_tip(old_child1->is_tip());
        
        new_child2->set_expect_subs_site(old_child2->get_brnlen());
        new_child2->set_name(old_child2->get_name());
        new_child2->set_tip(old_child2->is_tip());
        
        if (old_child1->is_tip() == TRUE) {
            new_child1->set_taxa_id(tips_so_far);
            tips_so_far++;
        }
        if (old_child2->is_tip() == TRUE) {
            new_child2->set_taxa_id(tips_so_far);
            tips_so_far++;
        }
        
        if (old_child1->is_tip() == FALSE)
            rebuild_tree(old_child1, lookup_table, new_tree, tips_so_far);
        
        if (old_child2->is_tip() == FALSE)
            rebuild_tree(old_child2, lookup_table, new_tree, tips_so_far);
        
    }
    
}

BOOL tip_in_clade(string tip_name, Branch *start)
{
    BOOL ret_val;
    if (start->is_tip() == TRUE) {
        if (strcmp(start->get_name(),tip_name.c_str())==0 ) return(TRUE);
        else return(FALSE);
    }
    else {
        ret_val=tip_in_clade(tip_name, start->get_child(0));
        if (ret_val == FALSE)
            return(tip_in_clade(tip_name, start->get_child(1)));
        else return(ret_val);
    }
    
}


