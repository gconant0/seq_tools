#include "stdio.h"
#include <iostream>
#include "string.h"
#include "get_comp.h"
#include "read_seq.h"
#include "write_seq.h"
#include "gen_dna_funcs.h"



int main (int argc, char **argv)
{
  int i, ntaxa, nchars;
  char infile[100], outfile[100];
  Make_complement make_comp;
  Sequence_dataset *current_data, *compl_data;
  Read_Sequence *read_seq;
  Write_Sequence *write_seq;

  if (argc<3)
    cerr<<"Usage: compl_dna <infile> <outfile>\n";
  else
    {
      strcpy(infile, argv[1]);
      strcpy(outfile, argv[2]);
     
       switch(guess_dataformat(infile, strlen(infile)))
       {
       case NEXUS:
	 read_seq=new Read_Nexus;
	 break;
       case PIR:
	 read_seq=new Read_PIR;
	 break;
       case PHYLIP:
	 read_seq=new Read_Phylip_interleave;
	 break;
       case FASTA:
	 read_seq=new Read_FASTA;
	 break;
	 
       }

       switch(guess_dataformat(outfile, strlen(outfile)))
       {
       case NEXUS:
	 write_seq=new Write_Nexus(outfile, NUCLEIC);
	 break;
       case PIR:
	 write_seq=new Write_PIR(outfile, NUCLEIC);
	 break;
       case PHYLIP:
	 write_seq=new Write_Phylip_interleave(outfile, NUCLEIC);
	 break;
       case FASTA:
	 write_seq=new Write_FASTA(outfile, NUCLEIC);
	 break;
	 
       }
    
 
     current_data=read_seq->get_dataset(ntaxa, nchars, infile, FALSE);
     if (current_data==0)
       {
	 delete read_seq;
	 return(-1);
       }

     compl_data=new Sequence_dataset(ntaxa, nchars);

     for(i=0; i<ntaxa; i++)
       {
	 (*compl_data)[i].Assign_name((*current_data)[i].Sequence_name()); 
	 make_comp.get_complement((*current_data)[i], (*compl_data)[i] , (*current_data)[i].Sequence_size());
       }

     write_seq->write_dataset(ntaxa, nchars, compl_data);
     delete current_data;
     delete compl_data;
     delete read_seq;
     delete write_seq;

    }
}//end main



