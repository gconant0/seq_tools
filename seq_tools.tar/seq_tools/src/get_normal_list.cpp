#include <iostream>
#include <iomanip>
#include "string.h"
#include "libranlib.h"
#include "gen_dna_funcs.h"

using namespace::std;

int main (int argc, char **argv)
{
	int i, num;
	double mean, stddev;
	long seed, seed2;
	
	if(argc<6) {
		cerr<<"Usage: get_normal_list mean stddev number seed1 seed2\n";
		}
	else   {
        mean=string_to_float(argv[1]);
        stddev=string_to_float(argv[2]);
        num=string_to_int(argv[3]);
        seed = string_to_int(argv[4]);
        seed2 = string_to_int(argv[5]);
	
        setall(seed, seed2);
  	
	  
        for(i=0; i<num; i++)
			  cout<<gennor(mean,stddev)<<endl;
	  

	  getsd(&seed, &seed2);
	  
	  cout<<seed<<endl<<seed2<<endl; 

    }
}//end main
