#include <iostream>
#include <fstream>
#include <string>
#include "gen_dna_funcs.h"
#include "read_seq.h"
#include "write_seq.h"


using namespace::std;

int main (int argc, char **argv)
{
  int i, j, start=0, end=0, nchars, ntaxa, final_nchars;
  char infile[100], outfile[100];
  BOOL pro_seq=FALSE;
  DATATYPE cdata=NUCLEIC;
  Sequence_dataset *current_data, *final_dataset;
  Read_Sequence *read_seq;
  Write_Sequence *write_seq;
  char (*backconvert)(int)=&num_to_base;

 if (argc<6)
   {
     cerr<<"Usage: crop_seq <infile> <outfile> <start> <end> -d:(DNA/PROTEIN)\n";
     return(-1);
   }

 else
   {
     strcpy(infile, argv[1]);
     strcpy(outfile, argv[2]);
     
     start=string_to_int(argv[3]);;
     end=string_to_int(argv[4]);

     if (argv[5][3]=='P' || argv[5][3]=='p')
       {
	 pro_seq=TRUE;
	 cdata=PROTEIN;
	 backconvert=&num_to_aa;
       }
     
   
     switch(guess_dataformat(infile, strlen(infile)))
       {
       case NEXUS:
	 read_seq=new Read_Nexus;
	 break;
       case PIR:
	 read_seq=new Read_PIR;
	 break;
       case PHYLIP:
	 read_seq=new Read_Phylip_interleave;
	 break;
       case FASTA:
	 read_seq=new Read_FASTA;
	 break;
	 
       }

       switch(guess_dataformat(outfile, strlen(outfile)))
       {
       case NEXUS:
	 write_seq=new Write_Nexus(outfile, cdata);
	 break;
       case PIR:
	 write_seq=new Write_PIR(outfile, cdata);
	 break;
       case PHYLIP:
	 write_seq=new Write_Phylip_interleave(outfile, cdata);
	 break;
       case FASTA:
	 write_seq=new Write_FASTA(outfile, cdata);
	 break;
	 
       }   
	 
 

     current_data=read_seq->get_dataset(ntaxa, nchars, infile, pro_seq);   
     if (current_data==0)
       return(-1);

     final_nchars=end-start;

     final_dataset=new Sequence_dataset(ntaxa, final_nchars);
   
     for(i=0; i<ntaxa; i++)
       {
	(*final_dataset)[i].Assign_name((*current_data)[i].Sequence_name());

	 for(j=start; j<end; j++)
	   (*final_dataset)[i].Assign_site(j-start, (*current_data)[i][j]);
       }
        
     write_seq->write_dataset(ntaxa, final_nchars, final_dataset);
   
     delete final_dataset;
     delete current_data;
     delete read_seq;

     return(0);

   }
}//end main



