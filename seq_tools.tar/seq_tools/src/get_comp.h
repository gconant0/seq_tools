#ifndef ___GET_COMP_H___
#define ___GET_COMP_H___

#include "gen_dna_funcs.h"

class Make_complement {
 public:
  void get_complement (Molecule_Sequence &inseq, Molecule_Sequence &outseq, int size);
 private:
  int base_to_comp (int base);
};

#endif
