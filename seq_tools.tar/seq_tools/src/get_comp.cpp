#include <math.h>
#include "get_comp.h"

 void Make_complement::get_complement (Molecule_Sequence &inseq, Molecule_Sequence &outseq, int size)
{
  int i;

  for (i=0; i<size; i++)
    outseq.Assign_site(i, base_to_comp(inseq[(size-1)-i]));

}


int Make_complement::base_to_comp (int base)
{

switch (base) {
 case 3: 
   return 0;
   break;
	 
 case 1:
   return 2;
   break;
		
 case 0:
   return 3;
   break;
		
 case 2:
   return 1;
   break;

 case 4:
    return 5;
    break;

 case 5:
   return 4;
   break;

 default:
   return(6);
   break;
        }

}//end base_to_base
