#include <iostream>
#include <iomanip>
#include "string.h"
#include "libranlib.h"
#include "gen_dna_funcs.h"

using namespace::std;

int main (int argc, char **argv)
{
	int i, low_i, high_i, num;
	double low, high; 
	long seed, seed2;
	BOOL float_val=FALSE; 

	if(argc<6) {
		cerr<<"Usage: get_uniform low high number seed1 seed2 (-float)\n";
		}
	else   {
		
	  if (argc == 7) 
		  float_val=TRUE;

	  num=string_to_int(argv[3]);	  
	  seed = string_to_int(argv[4]);
	  seed2 = string_to_int(argv[5]);
	
	  setall(seed, seed2);
      
  
	  if (float_val == FALSE) {
		  low_i=string_to_int(argv[1]);
		  high_i=string_to_int(argv[2]);
	  }     
	  else {
		  low=string_to_float(argv[1]);
		  high=string_to_float(argv[2]);
	  }
	  
	  
	  for(i=0; i<num; i++) {
		  if (float_val == FALSE)
			  cout<<ignuin(low_i,high_i)<<endl;
		  else
			  cout<<genunf(low,high)<<endl;
	  }

	  getsd(&seed, &seed2);
	  
	  cout<<seed<<endl<<seed2<<endl; 

    }
}//end main

