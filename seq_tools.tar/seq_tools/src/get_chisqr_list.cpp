#include <iostream>
#include <iomanip>
#include "string.h"
#include "libranlib.h"
#include "gen_dna_funcs.h"

using namespace::std;

int main (int argc, char **argv)
{
	int i, low_i, high_i, num;
	double low, high, df;
	long seed, seed2;
	BOOL float_val=FALSE; 

	if(argc<5) {
		cerr<<"Usage: get_chiqr df number seed1 seed2\n";
		}
	else   {
		
      df =string_to_float(argv[1]);
	  num=string_to_int(argv[2]);
	  seed = string_to_int(argv[3]);
	  seed2 = string_to_int(argv[4]);
	
	  setall(seed, seed2);
      
  
	  
	  
	  for(i=0; i<num; i++)
			  cout<<genchi(df)<<endl;
	  

	  getsd(&seed, &seed2);
	  
	  cout<<seed<<endl<<seed2<<endl; 

    }
}//end main

