#include <iostream>
#include <fstream>
#include "string.h"
#include "gen_dna_funcs.h"
#include "read_seq.h"



int main (int argc, char **argv)
{
  int i, j, nchars, ntaxa;
  char infile[100], type[20];
  BOOL pro_seq=FALSE;
  Read_Sequence *read_seq;
  Sequence_dataset *current_data;

 if (argc<3)
   {
     cerr<<"Usage: get_seq_len <infile> -d:(DNA/PROTEIN)\n";
     return(-1);
   }
 else
   {
     strcpy(infile, argv[1]);
     
     if (argv[2][3]=='P' || argv[2][3]=='p')
       {
	 pro_seq=TRUE;
	 strcpy(type, " residues.");
       }
     else
       strcpy(type, " base pairs.");

     switch(guess_dataformat(infile, strlen(infile)))
       {
       case NEXUS:
	 read_seq=new Read_Nexus;
	 break;
       case PIR:
	 read_seq=new Read_PIR;
	 break;
       case PHYLIP:
	 read_seq=new Read_Phylip_interleave;
	 break;
       case FASTA:
	 read_seq=new Read_FASTA;
	 break;
	 
       }

    
       current_data=read_seq->get_dataset(ntaxa, nchars, infile, pro_seq);   
       if (current_data==0)
	 {
	   delete read_seq;
	   return(-1);
	 }

       for (i=0; i<current_data->Num_sequences(); i++)
	 cout<<(*current_data)[i].Sequence_name()<<"\t"<<(*current_data)[i].Sequence_size()<<endl;
 
       delete current_data;
       delete read_seq;
       return(0);
   }
}//end main



