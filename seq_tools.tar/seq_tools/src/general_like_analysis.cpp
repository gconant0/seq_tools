#include <iostream>
#include <math.h>
#include "maxlike.h"
#include "codon_like.h"
#include "exchange.h"
#include "tree.h"
#include "read_tree.h"
#include "read_seq.h"
#include "gen_code.h"
#include "powell.h"
#include "gen_dna_funcs.h"
#include "score_matrix.h"
#include "write_tree.h"
#include <string>

using namespace::std;

struct matrix_file_list {
	matrix_file_list *next, *last;
	char filename[100];
};

void parse_args(int argc, char **argv, Exchange *curr_exchange, BOOL &codon_freqs, BOOL &nogaps, BOOL &generic_tree, BOOL &nexusout, 
				BOOL &noposweights, BOOL &fix_zero_brn, AA_matrix **&the_matrices, Genetic_code *&curr_code,  string &group_file);
int get_num_groups(string group_file);

int main(int argc, char *argv[])
{
  int i=0, j,k, avg_cnt=0, ntaxa, nchars, temp_codon[3], descpt_lines, num_groups;
  string outtreefile, prog_name, group_file;
  double p_ns, avg_ks, avg_ka, final_lnL, temp, codon_basefreqs[3][4];
  BOOL codon_freqs, generic_tree, nexusout, nogaps, noposweights,fix_zero_brn;
 

  //Classes
  Exchange current_exchange;
  Read_PAUP_Tree *get_tree;
    Branch *reroot;
  Tree *current_tree;
  Read_Sequence *read_seqs;
  Sequence_dataset *nuc_data, *new_data,  *current_data;
  Write_Tree *writeout_tree;
  Genetic_code *current_genetic_code;
  AA_matrix **the_matrices=0;
  Like_model *model;
  Powell current_powell;
  
  if (argc>2)
  {  

  
    parse_args(argc, argv, &current_exchange, codon_freqs, nogaps, generic_tree, nexusout, noposweights, fix_zero_brn, the_matrices, current_genetic_code, group_file);
	prog_name="Tree from general_like_analysis";

    
      
    outtreefile.assign(current_exchange.get_treefile());
    outtreefile= outtreefile + ".out";
    
   
    current_exchange.set_num_rates(1);
	if (noposweights == TRUE)
		//Tell the exchange that positive weights in the LCAP model are not allowed
		current_exchange.disallow_LCAP_pos_weights();
    
    //Gets the data

    switch(guess_dataformat(current_exchange.get_datafile(), strlen(current_exchange.get_datafile())))
       {
       case NEXUS:
         read_seqs=new Read_Nexus;
         break;
       case PIR:
         read_seqs=new Read_PIR;
         break;
       case PHYLIP:
	 read_seqs=new Read_Phylip_interleave;
         break;
       case FASTA:
         read_seqs=new Read_FASTA;
         break;
       } 

    nuc_data=read_seqs->get_dataset(ntaxa, nchars, current_exchange.get_datafile(), FALSE);

    if (nuc_data==0)
      {
	delete read_seqs;
	return(-1);
      }

    
    if(nogaps == TRUE) {
      cout<<"Removing gap positions from alignment\n";
      new_data= remove_gaps (nuc_data, FALSE);
      delete nuc_data;
      nuc_data=new_data;
    }
    current_exchange.set_num_taxa(ntaxa);
    current_exchange.set_num_sites((*nuc_data)[0].Sequence_size());


    if (current_exchange.fixed_basefreq() == TRUE) {
      if (codon_freqs == FALSE) {
		cout<<"Using empirical base frequencies\n";
		for(i=0; i<4; i++) 
		current_exchange.set_basefreqs(observed_basefreqs (nuc_data, i), i);  
      }
      else {
		cout<<"Using codon-specific empirical frequencies\n";
		for(i=0; i<3; i++)
			for(j=0; j<4; j++)
				codon_basefreqs[i][j]= observed_codon_basefreqs(nuc_data, i, j);
	
			current_exchange.set_use_codon_basefreqs(codon_basefreqs);
      }

    }

    
    //Converts nucleotide data to the 61X61 coding for each codon
    current_data = current_genetic_code->make_codon_sequence(nuc_data);
	

    //Gets the tree
	if (generic_tree == TRUE)
		get_tree=new Read_PAUP_Tree();
	else
		get_tree=new Read_PAUP_w_Settings_Tree(&current_exchange);


     
	if (group_file != "") {
		delete current_exchange.curr_groups;
		num_groups=get_num_groups(group_file);
		current_exchange.curr_groups=new Amino_acid_group(num_groups, group_file.c_str());
	}
    
	current_tree=get_tree->create_tree_from_file(&current_exchange, current_data);

      reroot=current_tree->find_null_branch_id()->get_sibling();
     
      if (fix_zero_brn==TRUE) {
          current_exchange.fix_zero_brn_lens();
          for(i=0; i<current_exchange.get_num_branches(); i++) {
              //cout<<"Branch "<<i<<" has "<<(*current_tree)[i]->expect_subs_site()<<endl;
              if (((*current_tree)[i]->expect_subs_site() <= 1e-8) && ((*current_tree)[i] != current_tree->find_null_branch_id())
                  && ((*current_tree)[i] != current_tree->find_root())) {
                  (*current_tree)[i]->make_fixed_zero();
                  cout<<"Setting branch "<<i<<" to fixed 0 length ("<<(*current_tree)[i]->expect_subs_site()<<")\n";
              }
          }
      }
      
    if (current_tree==0)
      {
		delete read_seqs;
		delete current_data;
		delete nuc_data;
		for(i=0; i<current_exchange.get_num_matrices(); i++)
			delete the_matrices[i];
		delete[] the_matrices;
		return(-1);
      }

	if (generic_tree == TRUE)
		current_exchange.set_num_p_nonsyn(1);	
	else 
		current_tree->set_num_nonsyn_params();

    switch(current_exchange.get_model())
      {
		case LCAP_JC:
			model = new LCAP_JC_model (&current_exchange, current_data, current_tree, current_genetic_code);
			break;
		case LCAP_K2P:
			model = new LCAP_K2P_model (&current_exchange, current_data, current_tree, current_genetic_code);
			break;
		case LCAP_HKY:
			model = new LCAP_HKY_model (&current_exchange, current_data, current_tree, current_genetic_code);
			break;
		case C_00_JC:
			model = new C_00_JC_model (&current_exchange, current_data, current_tree, current_genetic_code);
			break;
		case C_00_K2P:
			model = new C_00_K2P_model (&current_exchange, current_data, current_tree, current_genetic_code);
			break;
		case C_00_HKY:
			model = new C_00_HKY_model (&current_exchange, current_data, current_tree, current_genetic_code);
			break;
		case MG_94_JC:
			model = new MG_94_JC_model (&current_exchange, current_data, current_tree, current_genetic_code);
			break;
		case MG_94_K2P:
			model = new MG_94_K2P_model (&current_exchange, current_data, current_tree, current_genetic_code);
			break;
		case MG_94_HKY:
			model = new MG_94_HKY_model (&current_exchange, current_data, current_tree, current_genetic_code);
			break;
		case AAMULMAT_JC:
			model = new MultiMatrix_JC_model (&current_exchange, current_data, current_tree, current_genetic_code, the_matrices);
			break;
		case AAMULMAT_K2P:
			model = new MultiMatrix_K2P_model (&current_exchange, current_data, current_tree, current_genetic_code, the_matrices);
			break;
		case AAMULMAT_HKY:
			model = new MultiMatrix_HKY_model (&current_exchange, current_data, current_tree, current_genetic_code, the_matrices);
			break;
	}
    
    cout<<current_exchange.get_num_params()<<endl;
    
    current_powell.set_tolerance(1e-6);
    cout<<"Begining global optimization\n"<<flush;
	model->find_ln_like_w_rates();
    current_exchange.set_saved_lnL(current_powell.Init_min(model, &current_exchange, TRUE));
      current_tree->name_branches();
      cout<<"Re-rooting at "<<reroot->get_name()<<endl;
      current_tree->re_root_tree(reroot);
      cout<<"Setting expected subs/site\n";
	model->set_expect_subs();
	current_exchange.set_obs_trs_trv(model->get_obs_trs_trv_ratio());
	cout<<"Observed trs_trv ratio: "<<model->get_obs_trs_trv_ratio()<<endl;
    
	for(i=0; i<current_exchange.get_num_p_non_syn(); i++)
		cout<<"P non-syn: "<<current_exchange.get_p_non_syn(i)<<endl;

    if(nexusout == TRUE)
          writeout_tree=new Write_Nexus_Tree();
	else
		writeout_tree=new Write_GCC_Tree();
	
	writeout_tree->write_tree(outtreefile.c_str(), prog_name.c_str(),
			the_matrices, current_tree, &current_exchange);

    
    delete model;
    delete current_tree;
    delete nuc_data;
    delete current_data;
    delete read_seqs;
	delete writeout_tree;
	delete current_genetic_code;
	if (current_exchange.get_num_matrices() > 0) {
		for(i=0; i<current_exchange.get_num_matrices(); i++)
			delete the_matrices[i];
		delete[] the_matrices;
	}
    return(0);
  } 
  else
    {
      cerr<<"Usage: general_like_analysis <alignment file> <treefile> -m:(MG94/C00/LCAP/AAMULMAT)(JC/K2P/HKY)"
		  <<"(-f:UNIFORM/BLOSUM62/<filename1>) (-f::UNIFORM/BLOSUM62/<filename2>) (-generic_tree) (-NEXUSouttree) "
		  <<"-d:(CHEMCOMP/POLARITY/VOLUME/HYDROPATHY/ISOELEC) (-obsfreqs/-codonfreqs) (-nogap) (-g:<groups file>) (-noposLCAP) (-zero_cys_cc) (-startopologyallowed)\n";
      return(-1);
    }
}  //End main



void parse_args(int argc, char **argv, Exchange *curr_exchange, BOOL &codon_freqs, BOOL &nogaps, BOOL &generic_tree, 
				BOOL &nexusout, BOOL &noposweights, BOOL &fix_zero_brn, AA_matrix **&the_matrices, Genetic_code *&curr_code, string &group_file)
{
	int i, j, num_matrices=0;
    string datafile, treefile;
	BOOL have_code=FALSE, zero_cys=FALSE;
	matrix_file_list *the_list=0, *curpos, *start;

	datafile.assign(argv[1]);
	treefile.assign(argv[2]);
	curr_exchange->set_datafile(datafile.c_str());
	curr_exchange->set_treefile(treefile.c_str());
	codon_freqs=FALSE;
	nogaps=FALSE;
	curr_exchange->set_model(MG_94_HKY);  
	generic_tree=FALSE;
	nexusout=FALSE;
	noposweights=FALSE;
    fix_zero_brn=FALSE;
	group_file="";
  
	if (argc>2) {
		for (i=3; i<argc; i++) {
            //cout<<"Parsing "<<argv[i]<<endl;
			switch (argv[i][1]) {
			case 'o':
			case 'O':
				curr_exchange->fix_basefreq();
				break;
			case 'c':
			case 'C':
				curr_exchange->fix_basefreq();
				codon_freqs=TRUE;
				break;
			case 'g':
			case 'G':
				if (argv[i][2] != ':') 
					generic_tree=TRUE;
				else {
                    group_file.assign(argv[i]);
                    group_file=group_file.substr(3, group_file.length()-3);
                }
				break;
			case 'n':
			case 'N':
                    if ((argv[i][2] == 'e') || (argv[i][2] == 'E')) {
                        nexusout=TRUE;
                        //cout<<"Will output a nexus tree\n";
                    }
                    else {
                        if ((argv[i][3] == 'g') || (argv[i][3] == 'G'))
                            nogaps=TRUE;
                        else
                            noposweights=TRUE;
                    }
			  break;
                case 's':
                case 'S':
                fix_zero_brn=TRUE;
                cout<<"Forcing zero-length branches to zero\n";
                break;
            case 'd':
			case 'D':
				//Disable an Amino Acid Property
				switch (argv[i][3])
				{
				case 'c':
				case 'C':
					curr_exchange->disable_property(CHEM_COMP);
					break;
				case 'i':
				case 'I':
					curr_exchange->disable_property(ISO_ELEC);
					break;
				case 'h':
				case 'H':
					curr_exchange->disable_property(HYDROPATHY);
					break;
				case 'p':
				case 'P':
					curr_exchange->disable_property(POLARITY);
					break;
				case 'v':
				case 'V':
					curr_exchange->disable_property(VOLUME);
					break;
				}
				break;
			case 'm':
			case 'M':
				//What model are we using?
				switch (argv[i][3]) {
				case 'm':
				case 'M':
					switch (argv[i][7]) {
						case 'j':
						case 'J':
							curr_exchange->set_model(MG_94_JC);  
							break;
						case 'k':
						case 'K':						
							curr_exchange->set_model(MG_94_K2P);
							break;
						case 'h':
						case 'H':
							curr_exchange->set_model(MG_94_HKY);
							break;
					}
					break;
				case 'c':
				case 'C':
					switch (argv[i][6]) {
						case 'j':
						case 'J':
							curr_exchange->set_model(C_00_JC);  
							break;
						case 'k':
						case 'K':						
							curr_exchange->set_model(C_00_K2P);
							break;
						case 'h':
						case 'H':
							curr_exchange->set_model(C_00_HKY);
							break;
					}
					break;
                
                case 'l':
				case 'L':
					switch (argv[i][7]) {
						case 'j':
						case 'J':
							curr_exchange->set_model(LCAP_JC);  
							break;
						case 'k':
						case 'K':						
							curr_exchange->set_model(LCAP_K2P);
							break;
						case 'h':
						case 'H':
							curr_exchange->set_model(LCAP_HKY);
							break;
					}
					break;
				case 'a':
				case 'A':
					
					switch (argv[i][11]) {
					case 'j':	
					case 'J':
						curr_exchange->set_model(AAMULMAT_JC);  
						break;
					case 'k':
					case 'K':						
						curr_exchange->set_model(AAMULMAT_K2P);
						break;
					case 'h':
					case 'H':
						curr_exchange->set_model(AAMULMAT_HKY);
						break;
					}
					break;
						
				}
				
				break;
			case 'v':
			case 'V':
					switch (argv[i][3]) {
						case 'u':
						case 'U':
							curr_exchange->set_genetic_code(UNIVERSAL);
							break;
						case 'v':
						case 'V':
							curr_exchange->set_genetic_code(VERT_MITO);
                            cout<<"Using vertebrate mitochondrial genetic code\n";
							break;
						case 'y':
						case 'Y':
							curr_exchange->set_genetic_code(YEAST_MITO);
                            cout<<"Using yeast mitochondrial genetic code\n";
							break;
						case 'm':
						case 'M':
                            if ((argv[6][4] == 'm') || (argv[6][4] == 'M')) {
								curr_exchange->set_genetic_code(MOLD_MITO);
                                cout<<"Using mold mitochondrial genetic code\n";
                            }
                            else {
								curr_exchange->set_genetic_code(MYCOPLASMA);
                                cout<<"Using mycoplasma genetic code\n";
                            }
							break;
							break;
							case 'i':
							case 'I':
                                curr_exchange->set_genetic_code(INVERT_MITO);
                                cout<<"Using invertebrate mitochondrial genetic code\n";
							break;
							case 'c':
							case 'C':
                                curr_exchange->set_genetic_code(CILIATE_NUC);
                                cout<<"Using ciliate nuclear genetic code\n";
							break;
							case 'e':
							case 'E':
                                curr_exchange->set_genetic_code(ECHINO_MITO);
                                cout<<"Using Echinoderm mitochondrial genetic code\n";
							break;
					}
					have_code=TRUE;
					break;
			case 'f':
			case 'F':
				j=3;
				num_matrices++;
				curpos=the_list;
				if(the_list != 0) {
					the_list->next=new matrix_file_list;
					the_list=the_list->next;
				}
				else
					the_list=new matrix_file_list;

				the_list->next=0;

				if(curpos == 0) {
					start=the_list;
					the_list->last=0;
				}
				else
					the_list->last=curpos;

				while(argv[i][j]!='\0' && (j<strlen(argv[i]))) {
					the_list->filename[j-3]=argv[i][j];
					j++;
				}
				the_list->filename[j-3]='\0';
				break;
			case 'z':
			case 'Z':
				//curr_code->use_zero_cys_cc();
					zero_cys=TRUE;
				break;
			}  
  
		}

		if ((curr_exchange->get_model() == AAMULMAT_HKY) ||
			(curr_exchange->get_model() == AAMULMAT_K2P) || (curr_exchange->get_model() == AAMULMAT_JC) ) {
			if (num_matrices == 0){
					num_matrices=1;
					the_matrices= new AA_matrix*[1];
					the_matrices[0] = new BLOSUM_62_matrix();
			}
			else { 
				the_matrices=new AA_matrix*[num_matrices];
				the_list=start;
				for(i=0; i<num_matrices; i++) {
					if (strcmp("UNIFORM", the_list->filename) == 0)
						the_matrices[i] = new Simple_AA_matrix();
					else if (strcmp("BLOSUM62", the_list->filename)==0)
						the_matrices[i]=new BLOSUM_62_matrix();
					else
						the_matrices[i] = new File_AA_matrix(the_list->filename);
					the_list=the_list->next;
				}

				curpos=start;
				do {
					the_list=curpos;
					curpos=the_list->next;
					delete the_list;
				} while (curpos != 0);
			
			}				

		
			curr_exchange->set_num_matrices(num_matrices);
		}
	}
	if(have_code==TRUE)
		curr_code=create_genetic_code(curr_exchange);
	else
		curr_code=new Genetic_code(curr_exchange, TRUE, "\0");

	curr_code->use_zero_cys_cc();
} 





int get_num_groups(string group_file)
{
	int i, group, max_g=0;
	char aa;
	ifstream infile;

	infile.open(group_file.c_str());
	if (infile.fail()) {
		cerr<<"Error: Invalid groups file\n";
		return(-1);
	}
	for (i=0; i<20; i++)
	{
		infile>>aa>>group;
		if(group>max_g)
			max_g=group;

	}
	infile.close();
	infile.clear();
	return(max_g);

}
