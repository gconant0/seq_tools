#include <iostream>
#include <string.h>
#include <fstream>
#include <math.h>
#include <linked_list.cpp>
#include "permute.cpp"


enum Obj_type {INTEGER, STRING, FLOATING_POINT};

class My_string {
public:
	My_string()   {the_string="";}
	int operator==(My_string test);	
	My_string& operator=(int assign_from);
	My_string& operator=(My_string &assign_from);
	void set_string(string new_string);
	string get_string()  {return(the_string);};
	int get_len()  {return(the_string.length());};
	~My_string ();
private:
	string the_string;

};

int main(int argc, char **argv)
{
	int i, num_objects,int_item, *int_data, *int_permute;
	string infile, outfile, in_string;
	double float_item,  *float_data, *float_permute;
	ifstream fin;
	ofstream fout;
    BOOL use_tree=FALSE;
	My_string string_item, *string_data, *string_permute;
	List<int> int_list;
	List<double> float_list;
	List<My_string> string_list;
	Permute<int> *int_permuter;
	Permute<double> *float_permuter;
	Permute<My_string> *string_permuter;
    Permute_with_Tree<int> *int_tree_permuter;
    Permute_with_Tree<double> *float_tree_permuter;
    Permute_with_Tree<My_string> *string_tree_permuter;
	Obj_type type=INTEGER;
	
	
	if (argc>3) {
		infile=argv[1];
		outfile=argv[2];
		
		switch (argv[3][0]) {
			case 'i':
			case'I':
				type=INTEGER;
				break;
			case'f':
			case 'F':
				type=FLOATING_POINT;
				break;
			case 's':
			case 'S':
				type=STRING;
				break;
        }
        if (argc > 4) use_tree=TRUE;
		
		fin.open(infile.c_str());
		
        if (fin.fail()) {
			cerr<<"Error opening file "<<infile<<endl;
			return(-1);
		}
				
		while (! fin.eof()) {
			switch (type) {
				case INTEGER:
					fin>>int_item;
					if(!fin.eof())
						int_list.add_to_list(int_item);
					break;
					
				case STRING:
					fin>>in_string;
					string_item.set_string(in_string);
					if(!fin.eof())
						string_list.add_to_list(string_item);
						
					break;
					
				case FLOATING_POINT:
					fin>>float_item;
					if(!fin.eof())
						float_list.add_to_list(float_item);
					break;
					
			}
        }
		fin.close();
		
		fout.open(outfile.c_str());
		
		if (fout.fail()) {
			cerr<<"Error opening file "<<outfile<<"\n";
			return(-1);
		}
		
		switch (type) {
			case INTEGER:
				num_objects=int_list.get_list_length();
				int_data=new int [num_objects];
				
				int_list.return_to_start();
				for(i=0; i<num_objects; i++) {
					int_data[i]=*(int_list.get_current_item());
					int_list.get_next();
				}
                
                if (use_tree == FALSE) {
                    int_permuter=new Permute<int>();
                    int_permute= int_permuter->do_permutation(num_objects, int_data);
				}
                else  {
                    int_tree_permuter=new Permute_with_Tree<int>();
                    int_permute= int_tree_permuter->do_permutation(num_objects, int_data);
                }
				for(i=0; i<num_objects; i++)
					fout<<int_permute[i]<<endl;
				
				delete[] int_data;
                delete[] int_permute;
                
                if (use_tree == FALSE)
                    delete int_permuter;
                else
                    delete int_tree_permuter;
				break;

				
			case STRING:
				num_objects=string_list.get_list_length();
				string_data=new My_string [num_objects];
				
				string_list.return_to_start();
				
				for(i=0; i<num_objects; i++) {
					string_data[i]=*(string_list.get_current_item());
					string_list.get_next();
				}
                if (use_tree == FALSE) {
                    string_permuter=new Permute<My_string>();
                    string_permute= string_permuter->do_permutation(num_objects, string_data);
                }
                else {
                    string_tree_permuter=new Permute_with_Tree<My_string>();
                    string_permute=string_tree_permuter->do_permutation(num_objects, string_data);
                }
                
				for(i=0; i<num_objects; i++) 
					fout<<string_permute[i].get_string()<<endl;
				
				delete[] string_data;
				delete[] string_permute;
                
                if (use_tree == FALSE)
                    delete string_permuter;
                else
                    delete string_tree_permuter;

				break;
				
			case FLOATING_POINT:
				num_objects=float_list.get_list_length();
				float_data=new double [num_objects];
				
				float_list.return_to_start();
				for(i=0; i<num_objects; i++) {
					float_data[i]=*(float_list.get_current_item());
					float_list.get_next();
				}
                if (use_tree == FALSE) {
                    float_permuter=new Permute<double>();
                    float_permute= float_permuter->do_permutation(num_objects, float_data);
                }
                else {
                    float_tree_permuter=new Permute_with_Tree<double>();
                    float_permute=float_tree_permuter->do_permutation(num_objects, float_data);
                }
        
				for(i=0; i<num_objects; i++) 
					fout<<float_permute[i]<<endl;
				
				delete[] float_data;
				delete[] float_permute;
                if (use_tree== FALSE)
                    delete float_permuter;
                else
                    delete float_tree_permuter;
				break;
		}
		
		fout.close();
		
		
		
		return(0);
	}
	else {
		cerr<<"Usage: permute_list <Input file> <Output file> Integer/String/FloatingPoint (-use_tree)\n";
		return(-1);
	}


}


	
int My_string::operator==(My_string test) 
{
	if (the_string != test.get_string())
			return(-1); 
	else 
		return(0);
}
	
My_string& My_string::operator=(int assign_from) {
    
    the_string="";
    
    return(*this);
}


My_string& My_string::operator=(My_string &assign_from)
{
		
	the_string=assign_from.get_string();
	
	return(*this);
	
}


void My_string::set_string(string new_string)
{
	
	the_string=new_string;
}


My_string::~My_string ()  
{
}
