#include <iostream>
#include <math.h>
#include "maxlike.h"
#include "nucleotide_like.h"
#include "exchange.h"
#include "tree.h"
#include "read_tree.h"
#include "read_seq.h"
#include "powell.h"
#include "gen_dna_funcs.h"
#include "write_tree.h"
#include <string.h>

void parse_args(int argc, char **argv, Exchange *curr_exchange, double &tol, BOOL &removegaps);

int main(int argc, char *argv[])
{
  int i=0, j,k, ntaxa, nchars;
  char  prog_name[50],  outtreefile[100];
  double tol;
  BOOL removegaps;

  //Classes
  Exchange current_exchange;
    Branch *reroot;
  Tree *current_tree;
  Read_PAUP_Tree get_tree;
  Read_Sequence *read_seqs;
  Sequence_dataset *current_data, *new_data;
  Like_model *model;
  Powell current_powell;
  Write_Nexus_Tree writeout_tree;
  
  if (argc>3)
  {  
    
    parse_args(argc, argv, &current_exchange, tol, removegaps);

    strcpy(outtreefile, current_exchange.get_treefile());      
    strcat(outtreefile, ".out");


    switch(guess_dataformat(current_exchange.get_datafile(), strlen(current_exchange.get_datafile())))
       {
       case NEXUS:
         read_seqs=new Read_Nexus;
         break;
       case PIR:
         read_seqs=new Read_PIR;
         break;
       case PHYLIP:
         read_seqs=new Read_Phylip_interleave;
         break;
       case FASTA:
         read_seqs=new Read_FASTA;
         break;
       } 
    
    //Gets the data
   
    current_data=read_seqs->get_dataset(ntaxa, nchars, current_exchange.get_datafile(), FALSE);
    if (current_data==0)
      {  
	delete read_seqs;
	return(-1);
      }

    current_exchange.set_num_taxa(ntaxa);
    current_exchange.set_num_sites(nchars);
    current_exchange.set_trs_trv(1.0);
    current_exchange.set_num_rates(1);
   
   
    if(removegaps == TRUE) {
      cout<<"Removing gap characters from sequences\n";
      new_data= remove_gaps (current_data, FALSE);
      delete current_data;
      current_data=new_data;
      nchars=(*current_data)[0].Sequence_size();
      current_exchange.set_num_sites(nchars);
    }

    
    //Gets the tree
    current_tree=get_tree.create_tree_from_file(&current_exchange, current_data);
    
    if (current_tree==0)
      {
	delete current_data;
	delete read_seqs;
	return(-1);
      }
   
       reroot=current_tree->find_null_branch_id()->get_sibling();
      
    if ((current_exchange.fixed_basefreq() == TRUE) && (current_exchange.get_model() == HKY_NUCLEOTIDE)) {
      cout<<"Using empirical base frequencies\n";
      for(i=0; i<4; i++) 
	current_exchange.set_basefreqs(observed_basefreqs (current_data, i), i);  
    }
    
     switch(current_exchange.get_model())
      {
      case JC_NUCLEOTIDE:
	model = new JC_Nucleotide_model (&current_exchange, current_data, current_tree);
	break;
      case K2P_NUCLEOTIDE:     
	model = new K2P_Nucleotide_model (&current_exchange, current_data, current_tree);
	break;
      case HKY_NUCLEOTIDE:
	model = new HKY_Nucleotide_model (&current_exchange, current_data, current_tree);
	break;
      }
      cout<<"The transition/transversion rate ratio is set to "<<current_exchange.get_trs_trv()<<endl;
      cout<<"The observed transition/transversion rate ratio is set to "<<current_exchange.get_obs_trs_trv()<<endl;
  
    if (tol != 0) {
      cout<<"Setting optimization tolerance to "<<tol<<endl;
      current_powell.set_tolerance(tol);
    }
    else
      tol=current_powell.get_tolerance();

    cout<<"Begining global optimization: there are "<<current_exchange.get_num_params()<<" parameters\n"<<flush;
   
    if (current_exchange.get_num_params() >1) {
      current_powell.Init_min(model, &current_exchange, TRUE);
      for(i=0; i<5; i++)
	model->newton_branch_opt();
     
    }
    else if (current_exchange.get_num_params() == 1) {
      current_powell.set_extern_model(model);
      model->min_single_param(model->get_param_type(0), tol);
    }
    else {
		cout<<"Initial lnL:"<<model->find_ln_like_w_rates()<<endl;
		for(i=0; i<8; i++)
		  {
		    cout<<"Opt # "<<i<<endl;
		    model->newton_branch_opt(0.0000001);
		  }
}
    current_exchange.set_saved_lnL(model->find_ln_like_w_rates());
      current_tree->re_root_tree(reroot);
    model->set_expect_subs();
    current_exchange.set_obs_trs_trv(model->get_obs_trs_trv_ratio());

    strcpy(prog_name, "Tree from find_nuc like");
   
   
    writeout_tree.write_tree(outtreefile, prog_name, current_tree, &current_exchange);

    
    delete model;
    delete current_tree;
    delete current_data;
    delete read_seqs;
    return(0);
  } 
  else
    {
      cerr<<"Usage: find_nuc_like <alignment file> <tree file> (JC/K2P/HKY) (-obsfreqs) (-t:#) (-nogap)\n";
      return(-1);
    }
}  //End main




void parse_args(int argc, char **argv, Exchange *curr_exchange, double &tol, BOOL &removegaps)
{
  int i, j;
  char datafile[100], treefile[100], tol_string[50];

  strcpy(datafile, argv[1]);
  strcpy(treefile, argv[2]);

  removegaps = FALSE;
  tol=0;

  curr_exchange->set_datafile(datafile);
  curr_exchange->set_treefile(treefile); 
  switch(argv[3][0])
    {
    case 'j':
    case 'J':
      curr_exchange->set_model(JC_NUCLEOTIDE);
      break;
    case 'k':
    case 'K':
      curr_exchange->set_model(K2P_NUCLEOTIDE);
      break;
    case 'h':
    case 'H':
      curr_exchange->set_model(HKY_NUCLEOTIDE);
      break;
    }
  
  if (argc>4) {
    for(i=4; i<argc; i++) {
      switch (argv[i][1]) {
      case 't':
      case 'T':
	j=3;
	while(j<strlen(argv[i])) 
	  tol_string[j-3]=argv[i][j++];
	tol=string_to_float(tol_string);
	break;
      case 'o':
      case 'O':
	curr_exchange->fix_basefreq();
	break;
      case 'n':
      case 'N':
	removegaps=TRUE;
	break;
      }
      
      
      
    }
    
  }
  
}






