#include <iostream>
#include <fstream>
#include <string>
#include "gen_dna_funcs.h"
#include "read_seq.h"
#include "write_seq.h"


using namespace::std;


int main (int argc, char **argv)
{
  int i, j, nchars, ntaxa;
  char infile[100], outfile[100];
  BOOL pro_seq=FALSE;
  DATATYPE cdata=NUCLEIC;
  Read_Sequence *read_seq;
  Write_Sequence *write_seq;
  Sequence_dataset *current_data;

 if (argc<4)
   {
     cerr<<"Usage: convert_format <infile> <outfile>  -d:(DNA/PROTEIN)\n";
     return(-1);
   }
 else
   {
     strcpy(infile, argv[1]);
     strcpy(outfile, argv[2]);
     
     if (argv[3][3]=='P' || argv[3][3]=='p')
       {
	 pro_seq=TRUE;
	 cdata=PROTEIN;
       }

     switch(guess_dataformat(infile, strlen(infile)))
       {
       case NEXUS:
	 read_seq=new Read_Nexus;
	 break;
       case PIR:
	 read_seq=new Read_PIR;
	 break;
       case PHYLIP:
	 read_seq=new Read_Phylip_interleave;
	 break;
       case FASTA:
	 read_seq=new Read_FASTA;
	 break;
	 
       }

       switch(guess_dataformat(outfile, strlen(outfile)))
       {
       case NEXUS:
	 write_seq=new Write_Nexus(outfile, cdata);
	 break;
       case PIR:
	 write_seq=new Write_PIR(outfile, cdata);
	 break;
       case PHYLIP:
	 write_seq=new Write_Phylip_interleave(outfile, cdata);
	 break;
       case FASTA:
	 write_seq=new Write_FASTA(outfile, cdata);
	 break;
	 
       }
    
	
    
       current_data=read_seq->get_dataset(ntaxa, nchars, infile, pro_seq);   
       if (current_data==0 || write_seq->fail()==TRUE)
	 {
	   delete read_seq;
	   delete write_seq;
	   return(-1);
	 }

       write_seq->write_dataset(ntaxa, nchars, current_data);
       
       delete current_data;
       delete read_seq;
       delete write_seq;
       return(0);
   }
}//end main



