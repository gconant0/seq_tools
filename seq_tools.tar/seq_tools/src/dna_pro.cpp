#include <iostream>
#include <iomanip>
#include "string.h"
#include "gen_code.h"
#include "gen_dna_funcs.h"
#include "read_seq.h"
#include "write_seq.h"
#include "exchange.h"



int main (int argc, char **argv)
{
  int i, j, codon[3], ntaxa, nchars, *lengths;
  string  infile, outfile, code;
  Sequence_dataset *current_data, *protein_sequences;
  Exchange current_exchange;
  Genetic_code *current_code;
  Read_Sequence *read_seq;
  Write_Sequence *write_seq;

  if(argc<3) {
      cerr<<"Usage: dna_pro <DNA sequence file> <protein sequence file> (-v:(U/VM/YM/MM/IM/CM/EM))\n";
      return(-1);
    }

  else {
      infile=argv[1];
      outfile=argv[2];
      
      if (argc > 3) {
          switch (argv[3][3]) {
              case 'u':
              case 'U':
                  current_exchange.set_genetic_code(UNIVERSAL);
                  break;
              case 'v':
              case 'V':
                  current_exchange.set_genetic_code(VERT_MITO);
                  break;
              case 'y':
              case 'Y':
                  current_exchange.set_genetic_code(YEAST_MITO);
                  break;
              case 'm':
              case 'M':
                  if ((argv[6][4] == 'm') || (argv[6][4] == 'M'))
                      current_exchange.set_genetic_code(MOLD_MITO);
                  else
                      current_exchange.set_genetic_code(MYCOPLASMA);
                  break;
                  break;
              case 'i':
              case 'I':
                  current_exchange.set_genetic_code(INVERT_MITO);
                  break;
              case 'c':
              case 'C':
                  current_exchange.set_genetic_code(CILIATE_NUC);
                  break;
              case 'e':
              case 'E':
                  current_exchange.set_genetic_code(ECHINO_MITO);
                  break;
          }
          
      }
      else current_exchange.set_genetic_code(UNIVERSAL);
  
      current_code=create_genetic_code(&current_exchange);
      
      switch(guess_dataformat(infile.c_str(), infile.length()))       {
       case NEXUS:
          read_seq=new Read_Nexus;
          break;
       case PIR:
          read_seq=new Read_PIR;
          break;
       case PHYLIP:
          read_seq=new Read_Phylip_interleave;
          break;
       case FASTA:
          read_seq=new Read_FASTA;
          break;
       }

       switch(guess_dataformat(outfile.c_str(), outfile.length()) )      {
       case NEXUS:
          write_seq=new Write_Nexus(outfile.c_str(), PROTEIN);
          break;
       case PIR:
          write_seq=new Write_PIR(outfile.c_str(), PROTEIN);
          break;
       case PHYLIP:
          write_seq=new Write_Phylip_interleave(outfile.c_str(), PROTEIN);
          break;
       case FASTA:
          write_seq=new Write_FASTA(outfile.c_str(), PROTEIN);
          break;
	 
       }

      current_data=read_seq->get_dataset(ntaxa, nchars, infile.c_str(), FALSE);
      if (current_data==0 || write_seq->fail()==TRUE) {
          delete protein_sequences;
          delete read_seq;
          return(-1);
      }

      lengths=new int [ntaxa];

      for(i=0; i<ntaxa; i++)
              lengths[i]=(int)((*current_data)[i].Sequence_size()/3);

      protein_sequences=new Sequence_dataset(ntaxa, lengths);

      cout<<"Num taxa:" <<ntaxa<<endl;

      for(i=0; i<ntaxa; i++) {
          (*protein_sequences)[i].Assign_name((*current_data)[i].Sequence_name());
	  
	  //cout<<"Size of this protein sequence ("<<i<<": "<<(*current_data)[i].Sequence_name()<<"): "<<(*protein_sequences)[i].Sequence_size()<<" (NUC: "<<(*current_data)[i].Sequence_size()<<")"<<endl;

          for(j=0; j<(int)((*current_data)[i].Sequence_size()/3); j++) {
              if (num_to_base((*current_data)[i][j*3])!='-') {
                  codon[0]=(*current_data)[i][j*3];
                  codon[1]=(*current_data)[i][j*3+1];
                  codon[2]=(*current_data)[i][j*3+2];
                  
                  (*protein_sequences)[i].Assign_site(j, readchar_to_aa(current_code->return_AA(codon)));
              }
              else  (*protein_sequences)[i].Assign_site(j, readchar_to_aa('-'));
          }
	 
      }
      
      write_seq->write_dataset(ntaxa, protein_sequences);

      delete current_data;
      delete protein_sequences;
      delete read_seq;
      return(0);

    }
}//end main

